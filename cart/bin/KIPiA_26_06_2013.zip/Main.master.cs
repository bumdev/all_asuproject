﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;

namespace kipia_web_application
{
    public partial class Main : ULMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetUserName();
        }
        private void GetUserName()
        {
            User u = GetCurrentUser();
            litUserName.Text = "Сеанс "+u.UserName;
        }
        protected void lbVodomerAdd_Click(object sender, EventArgs e)
        {

        }
        protected void lbAbonentAdd_Click(object sender, EventArgs e)
        {
            Wizard1.Visible = true;
        }        
    }
}