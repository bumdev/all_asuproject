﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Entities;
using DomainObjects;
using FirebirdSql.Data.FirebirdClient;
using System.Data;



namespace kipia_web_application
{
    public partial class Check_VodomerTake : ULPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {                
                CheckLogin();
                SetDate();
            }
            //dsJournal.SelectParameters.Add("@IsPaid", DbType.Boolean, "true");
        }
        private void CheckPermissions()
        {
            User u = GetCurrentUser();
            u.GetPermissions();
            if (u.ChekPermission(Permissions.AllOrder.ToString()))
            {
                SetUser(-1);
            }
            else
            {
                SetUser(u.Location);
            }
            
        }
        private void CheckLogin()
        {
            if (!IsLogin())
            {
                Response.Redirect("../Default.aspx");
            }
            else
            {
                CheckPermissions();
            }
        }
        private void SetUser(int id)
        {
            hfLocationID.Value = id.ToString();

        }
        private void SetDate()
        {
            tbSD.Text = DateTime.Now.AddMonths(-1).ToShortDateString();
            tbFD.Text = DateTime.Now.ToShortDateString();
        }

        private void ExecuteSearch()
        {
            DataView view = (DataView)dsJournal.Select(DataSourceSelectArguments.Empty);
        }

        protected void dsJournal_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {
            
            if (rbIsPaid.Checked)
            {
                e.Command.Parameters["@IsPaid"].Value = rbIsPaid.Checked;
            }
            if (rbIsNotPaid.Checked)
            {
                e.Command.Parameters["@IsPaid"].Value = !rbIsNotPaid.Checked;
            }
            if ((rbIsPaid.Checked && rbIsNotPaid.Checked) || (!rbIsPaid.Checked && !rbIsNotPaid.Checked))
            {
                e.Command.Parameters["@IsPaid"].Value = DBNull.Value;
            }


            if (string.IsNullOrEmpty(tbNumber.Text))
            {
                e.Command.Parameters["@OrderID"].Value = DBNull.Value;
            }
            if (string.IsNullOrEmpty(tbSD.Text))
            {
                e.Command.Parameters["@DateLow"].Value = DBNull.Value;
            }
            if (string.IsNullOrEmpty(tbFD.Text))
            {
                e.Command.Parameters["@DateHigh"].Value = DBNull.Value;
            }
            if (string.IsNullOrEmpty(tbName.Text))
            {
                e.Command.Parameters["@Abonent"].Value = DBNull.Value;
            }
            if (string.IsNullOrEmpty(tbVodomer.Text))
            {
                e.Command.Parameters["@FactoryNumber"].Value = DBNull.Value;
            }
        }

        protected void lbSearch_Click(object search, EventArgs e)
        {
            ExecuteSearch();
        }

        protected void gvJournal_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int index = 0;
            if (e.CommandName == "Details")
            {
                index = Convert.ToInt32(e.CommandArgument); //get row number selected
                GridViewRow row = gvJournal.Rows[index];
                

                FAbonDet1.Visible = true;
                FAbonDet1.OrderID = Convert.ToInt32((row.FindControl("OID") as HiddenField).Value);
                FAbonDet1.Bind();
            }
        }
    }
}