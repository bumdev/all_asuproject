﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using Entities;

namespace kipia_web_application
{
    /// <summary>
    /// Summary description for GetDocument
    /// </summary>
    public class GetDocument : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            if (context.Request["Commerce"] != null)
            {
                if (context.Request["Commerce"] == "0")
                {
                    Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outcommerce.docx"));
                    System.IO.MemoryStream mstream = new MemoryStream(bytData);
                    byte[] byteArray = mstream.ToArray();
                    mstream.Flush();
                    mstream.Close();
                    context.Response.Clear();
                    context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outcommerce.docx");
                    context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.BinaryWrite(byteArray);
                }
                if (context.Request["Commerce"] == "1")
                {
                    Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outnoncommerce.docx"));
                    System.IO.MemoryStream mstream = new MemoryStream(bytData);
                    byte[] byteArray = mstream.ToArray();
                    mstream.Flush();
                    mstream.Close();
                    context.Response.Clear();
                    context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outnoncommerce.docx");
                    context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.BinaryWrite(byteArray);
                }
            }
            if (context.Request["Act"] != null)
            {
                if (context.Request["Act"] == Abonent.Corporate.ToString())
                {
                    Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/Uact.xls"));
                    System.IO.MemoryStream mstream = new MemoryStream(bytData);
                    byte[] byteArray = mstream.ToArray();
                    mstream.Flush();
                    mstream.Close();
                    context.Response.Clear();
                    context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "Uact.xls");
                    context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.BinaryWrite(byteArray);
                }
                if (context.Request["Act"] == Abonent.Private.ToString())
                {
                    Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/Fact.xls"));
                    System.IO.MemoryStream mstream = new MemoryStream(bytData);
                    byte[] byteArray = mstream.ToArray();
                    mstream.Flush();
                    mstream.Close();
                    context.Response.Clear();
                    context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "Fact.xls");
                    context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.BinaryWrite(byteArray);
                }
                if (context.Request["Act"] == "PrivateSpecial")
                {
                    Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/out act_check.xls"));
                    System.IO.MemoryStream mstream = new MemoryStream(bytData);
                    byte[] byteArray = mstream.ToArray();
                    mstream.Flush();
                    mstream.Close();
                    context.Response.Clear();
                    context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "FactSpecial.xls");
                    context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                    context.Response.ContentType = "application/octet-stream";
                    context.Response.BinaryWrite(byteArray);
                }
               
            }
            if (context.Request["bill"] != null)
            {
                Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outBill.xls"));
                System.IO.MemoryStream mstream = new MemoryStream(bytData);
                byte[] byteArray = mstream.ToArray();
                mstream.Flush();
                mstream.Close();
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outBill.xls");
                context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                context.Response.ContentType = "application/octet-stream";
                context.Response.BinaryWrite(byteArray);
            }
            if (context.Request["order"] != null)
            {
                Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outorder.docx"));
                System.IO.MemoryStream mstream = new MemoryStream(bytData);
                byte[] byteArray = mstream.ToArray();
                mstream.Flush();
                mstream.Close();
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outorder.docx");
                context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                context.Response.ContentType = "application/octet-stream";
                context.Response.BinaryWrite(byteArray);
            }
            if (context.Request["pay"] != null)
            {
                Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outcheck.docx"));
                System.IO.MemoryStream mstream = new MemoryStream(bytData);
                byte[] byteArray = mstream.ToArray();
                mstream.Flush();
                mstream.Close();
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outcheck.docx");
                context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                context.Response.ContentType = "application/octet-stream";
                context.Response.BinaryWrite(byteArray);
            }
            if (context.Request["ordercheck"] != null)
            {
                Byte[] bytData = File.ReadAllBytes(context.Request.MapPath("~\\Templates/outorder_check.docx"));
                System.IO.MemoryStream mstream = new MemoryStream(bytData);
                byte[] byteArray = mstream.ToArray();
                mstream.Flush();
                mstream.Close();
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "outorder_check.docx");
                context.Response.AddHeader("Content-Length", byteArray.Length.ToString());
                context.Response.ContentType = "application/octet-stream";
                context.Response.BinaryWrite(byteArray);
            }
            //Я вот как делал. Прекрасно работает.ordercheck
            



            /*File.Open(context.Request.MapPath("~\\Templates/outcommerce.rtf"));
            context.Response.ContentType = "application/rtf";
            context.Response.AddHeader("Content-Disposition", "attachment; filename=" + "FileName");
            context.Response.BinaryWrite((byte[])rdr["FieldName"]);*/
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}