using System;
using System.Collections;

namespace Entities
{
    [Serializable]
	public class UniversalEntity : ArrayList
	{
		public UniversalEntity()
		{

		}		
	}
}
